package tree;

public class Tree_Node {
    Integer tree_date;
    String tree_strdate;
    String slashandbackslask;
    Tree_Node left;
    Tree_Node right;
    public Tree_Node() {}
    }
