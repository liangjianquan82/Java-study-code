package Ex10binarytree;

public class Tree_Node {
    public  Tree_Node(){}
    Integer intdata;
    String strdata;
    Tree_Node left_node;
    Tree_Node right_node;
}
